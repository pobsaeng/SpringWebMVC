package com.app.connectdb;

public class DatabaseInfo {
    public static final String URL = "jdbc:mysql://10.100.60.178/spring_hbn_app";
    public static final String USER = "Developer";
    public static final String PASSWORD = "password";
    public static final String DRIVER = "com.mysql.jdbc.Driver";
    
    private DatabaseInfo() {
    }
}