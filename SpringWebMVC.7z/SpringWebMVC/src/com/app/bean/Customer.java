package com.app.bean;

public class Customer {
	private Integer cusId;
	private String cusFirstName;
	private String cusLastName;
	private int cusAge;
	
	public Customer() {
		super();
	}

	public Customer(Integer cusId, String cusFirstName, String cusLastName, int cusAge) {
		super();
		this.cusId = cusId;
		this.cusFirstName = cusFirstName;
		this.cusLastName = cusLastName;
		this.cusAge = cusAge;
	}

	public Integer getCusId() {
		return cusId;
	}

	public void setCusId(Integer cusId) {
		this.cusId = cusId;
	}

	public String getCusFirstName() {
		return cusFirstName;
	}

	public void setCusFirstName(String cusFirstName) {
		this.cusFirstName = cusFirstName;
	}

	public String getCusLastName() {
		return cusLastName;
	}

	public void setCusLastName(String cusLastName) {
		this.cusLastName = cusLastName;
	}

	public int getCusAge() {
		return cusAge;
	}

	public void setCusAge(int cusAge) {
		this.cusAge = cusAge;
	}

	@Override
	public String toString() {
		return "Customer [cusId=" + cusId + ", cusFirstName=" + cusFirstName + ", cusLastName=" + cusLastName + ", cusAge=" + cusAge + "]";
	}
	

}
