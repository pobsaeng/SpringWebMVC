package com.app.bean;


public class Car {
	private Integer id;
	private String car_brand;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCar_brand() {
		return car_brand;
	}
	public void setCar_brand(String car_brand) {
		this.car_brand = car_brand;
	}
	public Car(Integer id, String car_brand) {
		super();
		this.id = id;
		this.car_brand = car_brand;
	}
	public Car() {
		super();
	}
	
}