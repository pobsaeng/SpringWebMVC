package com.app.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.app.bean.Car;
import com.app.connectdb.Database;
import com.google.gson.Gson;

@Controller
public class CustomerController {

	@RequestMapping(value = "/customer/listCustomers.action")
	@ResponseBody
	public Object getAllCustomer(){
		System.out.println("------getAllCustomer-------");
		try {
			Map<String, Object> modelMap = new HashMap<String, Object>(3);
			
			Database db = new Database();
			List<Map<String, Object>> result = db.queryList("select * from customer", null);
			
			modelMap.put("data", result);
			return modelMap;

		} catch (Exception e) {

			return getModelMapError("Error retrieving Contacts from database.");
		}
	}
	
	@RequestMapping(value="/method1.action", method=RequestMethod.POST)
	@ResponseBody
	public Object method2(){
		Map<String, Object> modelMap = new HashMap<String, Object>(3);
		String json = "{\"id\":\"213025\", \"car_brand\": \"Hello\"}";
		Gson gson = new Gson();
		Car car = gson.fromJson(json, Car.class);
		String jsonData = gson.toJson(car);
		modelMap.put("data", jsonData);
		
		return modelMap;
	}
	
	private Map<String, Object> getModelMapError(String msg) {

		Map<String, Object> modelMap = new HashMap<String, Object>(2);
		modelMap.put("message", msg);
		modelMap.put("success", false);

		return modelMap;
	}

}
